from django.shortcuts import render,redirect

from django.contrib.auth.models import User
from django.contrib.auth import authenticate,login
from employee.models import EmployeeModel

from employee.forms import UserForm,EmployeeForm,LoginForm
from django.views.generic import FormView,View,UpdateView,TemplateView

# Create your views here.

class EmployeeRegister(FormView):
    template_name ='employee_register.html'
    form_class = UserForm

    def get(self,request,*args,**kwargs):
        self.object=None
        form_class = self.get_form_class()
        user_form = self.get_form(form_class)
        empl_form = EmployeeForm()
        return self.render_to_response(self.get_context_data(form1=user_form, form2=empl_form))

    def post(self,request,*args,**kwargs):
        self.object=None
        form_class = self.get_form_class()
        user_form = self.get_form(form_class)
        empl_form = EmployeeForm(self.request.POST)
        if (user_form.is_valid() and empl_form.is_valid()):
            return self.form_valid(user_form, empl_form)
        else:
            return self.form_invalid(user_form, empl_form)

    def form_valid(self,user_form,empl_form):
        self.object = user_form.save() #User model save
        self.object.is_staff=True # edit user object
        self.object.save()
        empl_obj = empl_form.save(commit=False) #Customer Model save(contact,address,place,pincode,gender)
        empl_obj.basic_details=self.object #saving OneToOnefield ,edit cust_obj
        empl_obj.save()
        return super(EmployeeRegister, self).form_valid(user_form)

    def form_invalid(self,user_form,empl_form):
        return self.render_to_response(self.get_context_data(form1=user_form,form2=empl_form))

    def get_success_url(self, **kwargs):
        return('/general/index/')   

class EmployeeListing(View):
    template_name = 'employee_list1.html'
    def get(self,request):
        empl_list= EmployeeModel.objects.all()
        context ={
        'empl' : empl_list
        }
        return render(request,self.template_name,context)

class EmployeeDeleteView(View):
    template_name = 'employee_list1.html'        
    def get(self,request,pk):
        empl_obj = EmployeeModel.objects.get(id=pk).delete()
        empl_list = EmployeeModel.objects.all()
        context = {
        'empl' : empl_list
        }
        return render(request,self.template_name,context)


class UpdateView(UpdateView):
    template_name = 'employee_update1.html'
    fields = ['basic_details','contact','gender','pincode','place']
    model = EmployeeModel
    success_url = '/general/index/'

class LoginView(View):
    template_name = "login.html"
    form_class = LoginForm

    def get(self,request):
        form = LoginForm
        context ={
            'form':form
        }
        return render(request,self.template_name,context)


    def post(self,request):
        username = request.POST['username']
        password = request.POST['password']
        user =authenticate(request,username=username,password=password)
        if user is user is not None:

            login(request,user)
            uname = request.user
            try:
                user_obj= User.objects.get(username=uname)
                empl = EmployeeModel.objects.get(basic_details=user_obj)
                

            except:
                user_obj=None    
                cust=None

            if request.user.is_superuser:
                return redirect('/general/adminn/')
            elif empl:
                return redirect('/employee/index/')
            else:
                return redirect('login')


        else:
            return redirect('login')

class IndexLogin(TemplateView):
    template_name = 'logout_index.html'             





