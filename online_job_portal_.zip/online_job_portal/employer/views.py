from django.shortcuts import render,redirect

from django.contrib.auth.models import User
from django.contrib.auth import authenticate,login
from employer.models import EmployerModel

from employer.forms import UserForm,EmployerForm,LoginForm
from django.views.generic import FormView,View,UpdateView,TemplateView
# Create your views here.

class EmployerRegister(FormView):
    template_name ='employer_register.html'
    form_class = UserForm

    def get(self,request,*args,**kwargs):
        self.object=None
        form_class = self.get_form_class()
        user_form = self.get_form(form_class)
        emp_form =EmployerForm()
        return self.render_to_response(self.get_context_data(form1=user_form, form2=emp_form))

    def post(self,request,*args,**kwargs):
        self.object=None
        form_class = self.get_form_class()
        user_form = self.get_form(form_class)
        emp_form = EmployerForm(self.request.POST)
        if (user_form.is_valid() and emp_form.is_valid()):
            return self.form_valid(user_form, emp_form)
        else:
            return self.form_invalid(user_form, emp_form)

    def form_valid(self,user_form,emp_form):
        self.object = user_form.save() #User model save
        self.object.is_staff=True # edit user object
        self.object.save()
        emp_obj = emp_form.save(commit=False) #Customer Model save(contact,address,place,pincode,gender)
        emp_obj.basic_details=self.object #saving OneToOnefield ,edit cust_obj
        emp_obj.save()
        return super(EmployerRegister, self).form_valid(user_form)

    def form_invalid(self,user_form,emp_form):
        return self.render_to_response(self.get_context_data(form1=user_form,form2=emp_form))

    def get_success_url(self, **kwargs):
        return('/general/index/') 


class EmployerListing(View):
    template_name = 'employer_list.html'
    def get(self,request):
        em_list= EmployerModel.objects.all()
        context ={
        'emp' : em_list
        }
        return render(request,self.template_name,context)


class EmployerDeleteView(View):
	template_name = 'employer_list.html'		
	def get(self,request,pk):
		cat_obj = EmployerModel.objects.get(id=pk).delete()
		em_list =EmployerModel.objects.all()
		context = {
		'emp' : em_list
		}
		return render(request,self.template_name,context)

class UpdateView(UpdateView):
    template_name = 'employer_update.html'
    fields = ['basic_details','contact','gender','pincode','place']
    model = EmployerModel
    success_url = '/general/admin1/'


class LoginView(View):
    template_name = "login.html"
    form_class = LoginForm

    def get(self,request):
        form = LoginForm
        context ={
            'form':form
        }
        return render(request,self.template_name,context)


    def post(self,request):
        username = request.POST['username']
        password = request.POST['password']
        user =authenticate(request,username=username,password=password)
        if user is user is not None:

            login(request,user)
            uname = request.user
            try:
                user_obj= User.objects.get(username=uname)
                emp = EmployerModel.objects.get(basic_details=user_obj)


                
            except:
                user_obj=None
                emp=None
            if request.user.is_superuser:
                return redirect('/general/adminn')
            elif emp:
                return redirect('/general/employeer')
            else:
                return redirect('login')


        else:
            return redirect('login')

class IndexLogin(TemplateView):
    template_name = 'logout_index.html'             









