# -*- coding: utf-8 -*-
from django.shortcuts import render,redirect
from django.views.generic import TemplateView,View,UpdateView
from general.models import ContactModel,CategoryModel,JobCategoryModel
from general.forms import ContactForm,JobForm,CategoryForm

# Create your views here.
class HomePageView(TemplateView):
	template_name='index.html'

class ContactUsView(View):
	template_name = 'contact2.html'
	form_class = ContactForm

	def get(self,request):
		form = self.form_class()
		context = {
		'conct_form':form
		}
		return render(request,self.template_name,context)

	def post(self,request):
		form = self.form_class(request.POST)
		if form.is_valid():
			conct = ContactModel.objects.create(
				name = request.POST.get('name'),
				email = request.POST.get('email'),
				contact = request.POST.get('contact'),
				message = request.POST.get('message')
				)
			return redirect('/general/contactsucess/')	
		else:
			form = self.form_class()
			return render(request,self.template_name,{'form':form})


class FeedbackListView(View):
	template_name ='contact_list.html'
	def get(self,request):
		cat_list=ContactModel.objects.all()
		context = {
		'job' : cat_list
		}
		return render(request,self.template_name,{'form':form})


		





class ContactSucessView(TemplateView):
	template_name = 'contactsuccess.html'
class AboutUsView(TemplateView):
	template_name = 'abt.html'	

class AdminView(TemplateView):
	template_name = 'admin1.html'

class EmployeView(TemplateView):
	template_name ='employeer.html'	


class CategoryView(View):
	template_name = 'category.html'
	form_class = CategoryForm
	
	def get(self,request):
		form = self.form_class()
		context = {
		'category_form':form
		}
		return render(request,self.template_name,context)

	def post(self,request):
		form = self.form_class(request.POST)
		if form.is_valid():
			job_cat = CategoryModel.objects.create(
				category = request.POST.get('category'),
				)
			return redirect('/general/categorylist/')
		else:
			form = self.form_class()
			return render(request,self.template_name,{'form':form})


class ListCategoryView(View):
	template_name ='category_list1.html'
	def get(self,request):
		cat_list=CategoryModel.objects.all()
		context = {
		'job' : cat_list
		}
		return render(request,self.template_name,context)

class CategoryDetailView(View):
	template_name = 'category_detail.html'

	def get(self,request,pk):
		obj = CategoryModel.objects.get(id=pk)
		context	= {
		'job' :obj
		}
		return render(request,self.template_name,context)

class CateogryDeleteView(View):
	template_name = 'category_list1.html'		
	def get(self,request,pk):
		cat_obj = CategoryModel.objects.get(id=pk).delete()
		cat_list = CategoryModel.objects.all()
		context = {
		'job' : cat_list
		}
		return render(request,self.template_name,context)


class EmployeeJobsListView(View):
	template_name = 'job2.html'
	form_class = JobForm
	
	def get(self,request):
		form = self.form_class()
		context = {
		'job_form':form
		}
		return render(request,self.template_name,context)

	def post(self,request):
		form = self.form_class(request.POST)
		if form.is_valid():
			cat_obj = CategoryModel.objects.get(id=request.POST.get('job_category'))
			job_cat = JobCategoryModel.objects.create(
				title  = request.POST.get('title'),
				location = request.POST.get('location'),
				job_category = cat_obj,
				job_qualification= request.POST.get('job_qualification'),
				job_experience= request.POST.get('job_experience'),
				job_description =request.POST.get('job_description'),
				salary= request.POST.get('salary'),
				company_name= request.POST.get('company_name'),
				company_description= request.POST.get('company_description'),
				)
			return redirect('/general/aboutus/')
		else:
			form = self.form_class()
			return render(request,self.template_name,{'form':form})


class ListJobView(View):
	template_name ='job_list1.html'
	def get(self,request):
		job_list=JobCategoryModel.objects.all()
		context = {
		'job' : job_list
		}
		return render(request,self.template_name,context)



class JobDetailView(View):
	template_name = 'job_detail.html'

	def get(self,request,pk):
		obj = JobCategoryModel.objects.get(id=pk)
		context	= {
		'job' :obj
		}
		return render(request,self.template_name,context)


class JobDeleteView(View):
	template_name = 'job_list1.html'		
	def get(self,request,pk):
		cat_obj = JobCategoryModel.objects.get(id=pk).delete()
		job_list =JobCategoryModel.objects.all()
		context = {
		'job' : job_list
		}
		return render(request,self.template_name,context)


class UpdateView(UpdateView):
    template_name = 'update_item.html'
    fields = ['title','location','job_category','job_qualification','job_experience','job_description','salary','company_name','company_description']
    model = JobCategoryModel
    success_url = '/general/joblist/'





class ListJobinfoView(View):
	template_name ='job_info_list1.html'
	def get(self,request):
		job_list=JobCategoryModel.objects.all()
		context = {
		'job' : job_list
		}
		return render(request,self.template_name,context)


class JobInfoDetailView(View):
	template_name = 'job_detail1.html'

	def get(self,request,pk):
		obj = JobCategoryModel.objects.get(id=pk)
		context	= {
		'job' :obj
		}
		return render(request,self.template_name,context)



    