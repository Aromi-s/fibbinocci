from django import forms

from general.models import ContactModel,CategoryModel,JobCategoryModel
	

class ContactForm(forms.ModelForm):
	class Meta:
		model = ContactModel
		fields = ['name','email','contact','message']
class JobForm(forms.ModelForm):
	class Meta:
		model=JobCategoryModel
		exclude=('created_on',)

class CategoryForm(forms.ModelForm):
	class Meta:
		model= CategoryModel
		exclude=['status','created_on']
