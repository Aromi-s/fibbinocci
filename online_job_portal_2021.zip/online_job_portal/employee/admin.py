# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.contrib import admin
from employee.models import EmployeeModel
# Register your models here.
admin.site.register(EmployeeModel)

