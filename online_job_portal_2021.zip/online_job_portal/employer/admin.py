# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.contrib import admin
from employer.models import EmployerModel
# Register your models here.
admin.site.register(EmployerModel)
