from django.conf.urls import url
from django.contrib import admin
from django.conf.urls.static import static
from django.conf import settings

from employee.views import EmployeeRegister,EmployeeListing,EmployeeDeleteView,UpdateView

urlpatterns = [
    url(r'register/',EmployeeRegister.as_view(),name='emp_reg'),
    url(r'employeelist/',EmployeeListing.as_view(),name='employe_list'),
    url(r'delete/(?P<pk>[0-9]+)/$',EmployeeDeleteView.as_view(),name='delete_details'), 
    url(r'update/(?P<pk>[0-9]+)/$',UpdateView.as_view(),name='update_details'),
  

    
]+ static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
if settings.DEBUG:
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)